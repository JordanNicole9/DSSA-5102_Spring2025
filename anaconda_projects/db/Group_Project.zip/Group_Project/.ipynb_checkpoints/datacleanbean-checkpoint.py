import pandas as pd

# Load data with error-tolerant settings
file_path = r"C:\Users\jorda\Documents\Data_Gathering\Group_Project\coffee.csv"
df = pd.read_csv(file_path, on_bad_lines='skip', encoding='utf-8', engine='python')

# Remove unnamed/empty columns and duplicates
df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
df.dropna(how='all', inplace=True)
df.drop_duplicates(inplace=True)

# Normalize column names
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

# Rename unclear columns
df.rename(columns={
    'rst_ground_dom_consum': 'roast_ground_domestic_consumption',
    'soluble_dom_cons': 'soluble_domestic_consumption'
}, inplace=True)

# Filter to only key source countries
source_countries = ['Brazil', 'Colombia', 'Guatemala', 'Vietnam', 'Switzerland', 'Canada']
df = df[df['country'].str.strip().str.replace("'", "")\
       .isin(source_countries)]

# Optional: keep only relevant columns for analysis
columns_of_interest = [
    'country', 'year',
    'arabica_production', 'robusta_production', 'other_production', 'production',
    'bean_exports', 'bean_imports',
    'roast_&_ground_exports', 'roast_&_ground_imports',
    'soluble_exports', 'soluble_imports',
    'domestic_consumption', 'roast_ground_domestic_consumption',
    'soluble_domestic_consumption', 'total_distribution', 'total_supply'
]
columns_to_keep = [col for col in columns_of_interest if col in df.columns]
df = df[columns_to_keep]

# Fill missing numeric values with 0
for col in df.select_dtypes(include='number').columns:
    df[col] = df[col].fillna(0)

# Save cleaned and filtered data
output_path = r"C:\Users\jorda\Documents\Data_Gathering\Group_Project\bean_source.csv"
df.to_csv(output_path, index=False)

print(f"✅ Cleaned and filtered coffee data saved to: {output_path}")
