# Script that cleaned the sourcing data set 

# Import necessary libraries 
import pandas as pd

# Loading in the data 
file_path = r"C:\Users\jorda\Documents\Data_Gathering\Group_Project\coffee.csv"
df = pd.read_csv(file_path, on_bad_lines='skip', encoding='utf-8', engine='python')

# I am only selecting a certain amount of countries and they have complete data.
# So I am dropping the duplicates and nas
df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
df.dropna(how='all', inplace=True)
df.drop_duplicates(inplace=True)

# Normalizing column names
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

# Renaming unclear columns
df.rename(columns={
    'rst_ground_dom_consum': 'roast_ground_domestic_consumption',
    'soluble_dom_cons': 'soluble_domestic_consumption'
}, inplace=True)

# Filtering to only key source countries
source_countries = ['Brazil', 'Colombia', 'Guatemala', 'Vietnam', 'Switzerland', 'Canada']
df = df[df['country'].str.strip().str.replace("'", "")\
       .isin(source_countries)]

# I am also only going to keep the columns that match what I need for this project.
columns_of_interest = [
    'country', 'year',
    'arabica_production', 'robusta_production', 'other_production', 'production',
    'bean_exports', 'bean_imports',
    'roast_&_ground_exports', 'roast_&_ground_imports',
    'soluble_exports', 'soluble_imports',
    'domestic_consumption', 'roast_ground_domestic_consumption',
    'soluble_domestic_consumption', 'total_distribution', 'total_supply'
]
columns_to_keep = [col for col in columns_of_interest if col in df.columns]
df = df[columns_to_keep]

# I am now going back in aand filling the missing numeric values with 0s
for col in df.select_dtypes(include='number').columns:
    df[col] = df[col].fillna(0)

# Saving cleaned and filtered data
# Defining the file path 
output_path = r"C:\Users\jorda\Documents\Data_Gathering\Group_Project\bean_source.csv"
df.to_csv(output_path, index=False)
# Sanity check 
print(f"Cleaned and filtered coffee data saved to: {output_path}")
