-- Using the coffee database
USE coffee2;

-- --------------------------------------------------
-- Query 1: Top 5 best-selling products by total quantity sold
-- --------------------------------------------------
SELECT 
    p.product,                           -- Product name
    SUM(t.quantity) AS total_sold       -- Total quantity sold for each product
FROM transaction_metrics t
JOIN product p ON t.product_id = p.product_id  -- Joins on product ID
GROUP BY p.product                      -- Groups results by product name
ORDER BY total_sold DESC                -- Sorts by highest total sold
LIMIT 5;                                -- Limits to top 5 products

-- --------------------------------------------------
-- Query 2: Total quantity sold by unit price
-- --------------------------------------------------
SELECT 
    p.unit_price,                        -- Unit price of each product
    SUM(t.quantity) AS total_sold       -- Total quantity sold at that price
FROM transaction_metrics t
JOIN product p ON t.product_id = p.product_id  -- Joins on product ID
GROUP BY p.unit_price                   -- Groups by unit price
ORDER BY p.unit_price;                  -- Sorts in ascending order of the unit price

-- --------------------------------------------------
-- Query 3: Number of transactions per hour 
-- --------------------------------------------------
SELECT 
    HOUR(transaction_time) AS hour,     -- Extracts the hour from the transaction timestamp
    COUNT(*) AS total_transactions      -- Counts total transactions in each hour
FROM transaction_metrics
GROUP BY hour                           -- Groups by hour
ORDER BY hour;                          -- Sorts by hour ascending

-- --------------------------------------------------
-- Query 4: Total bean imports by country
-- --------------------------------------------------
SELECT 
    country,                            -- Country name
    SUM(bean_imports) AS total_imports -- Total amount of beans imported from each country
FROM sourcing
GROUP BY country                        -- Groups results by country
ORDER BY total_imports DESC;           -- Sorts by largest total imports

-- --------------------------------------------------
-- Query 5: Total sales revenue by location type
-- --------------------------------------------------
SELECT 
    t.location_type,                                           -- In-Store or Online
    SUM(t.quantity * p.unit_price) AS total_sales              -- Total revenue 
FROM transaction_metrics t
JOIN product p ON t.product_id = p.product_id                 -- Joins product details for unit price
GROUP BY t.location_type                                      -- Groups by location type
ORDER BY total_sales DESC;                                    -- Sorts from highest to lowest revenue

